# ringd

Initial commit.

## Project Status

Alpha.  Code and unit tests exist, but some tests fail.

## On-line Documentation

More information on the **ringd** project can be found
[here](https://jddixon.github.io/ringd)
